import React, { useState } from 'react';

function MyForm() {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        message: '',
        gender: '',
        agree: false,
        department: ''
    });

    const [submitted, setSubmitted] = useState(false);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: type === 'checkbox' ? checked : value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Set the submitted state to true
        setSubmitted(true);
        // Do something with the form data, like sending it to a server
        console.log(formData);
        // Reset form fields
        setFormData({
            name: '',
            email: '',
            message: '',
            gender: '',
            agree: false,
            department: ''
        });
    };

    return (
        <div className="container">
            <img src="https://www.netclues.in/front-media/Themes/ThemeDefault/images/logo.png" alt="Logo" style={{ display: 'block', margin: '0 auto', maxWidth: '150%', marginBottom: '20px' }} />
            <h2>Contact Us</h2>
            <form onSubmit={handleSubmit}>
                {/* Your form inputs */}
                <button type="submit">Submit</button>
            </form>

            {/* Conditionally render the submitted data */}
            {submitted && (
                <div>
                    <h3>Submitted Data:</h3>
                    <p>Name: {formData.name}</p>
                    <p>Email: {formData.email}</p>
                    <p>Message: {formData.message}</p>
                    <p>Gender: {formData.gender}</p>
                    <p>Department: {formData.department}</p>
                </div>
            )}
        </div>
    );
}

export default MyForm;


// const { name, value, type, checked } = e.target;: This line extracts properties from the event target (e.target), which is the form element that triggered the event. name represents the name attribute of the form element, value represents the current value of the form element, type represents the type of the form element (e.g., text, checkbox, radio), and checked is applicable for checkboxes and radio buttons, representing whether the checkbox or radio button is checked.

// setFormData(prevState => ({ ...prevState, [name]: type === 'checkbox' ? checked : value }));: This line updates the form data state (formData) based on the input change. It uses the functional form of setFormData, where the previous state (prevState) is passed as an argument. It spreads the previous state (...prevState) to retain any existing form data and then updates the property corresponding to the input element's name ([name]). For checkboxes, it updates the value based on whether the checkbox is checked (checked), and for other input types, it updates the value based on the input's current value (value).

// setShowData(false): This line sets the showData state to false. It seems like it's intended to hide any previously displayed data whenever a form field changes. However, this line might not be necessary, depending on the behavior you want. In your case, since you want to display the submitted data after the form is submitted, resetting showData to false here will prevent the submitted data from being displayed. You may consider removing this line if you want to keep the submitted data displayed after submission.

// In summary, the handleChange function updates the form data state based on the user's input and optionally resets the state controlling the display of submitted data.