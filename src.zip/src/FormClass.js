import React, { Component } from 'react';

class MyFormClass extends Component {
    constructor(props) {
        super(props);
        this.state = {
            formData: {
                name: '',
                email: '',
                message: '',
                gender: '',
                agree: false,
                department: ''
            },
            showData: false
        };
    }

    handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        this.setState(prevState => ({
            formData: {
                ...prevState.formData,
                [name]: type === 'checkbox' ? checked : value
            },
            showData: false
        }));
    };

    handleSubmit = (e) => {
        e.preventDefault();
        this.setState({ showData: true });
    };

    render() {
        const { formData, showData } = this.state;

        return (
            <div className="container">
                <img src="https://www.netclues.in/front-media/Themes/ThemeDefault/images/logo.png" alt="Logo" style={{ display: 'block', margin: '0 auto', maxWidth: '150%', marginBottom: '20px' }} />
                <h2>Contact Us</h2>
                <form onSubmit={this.handleSubmit}>
                    <div className="form-group">
                        <label className="label-text" htmlFor="name">Name:</label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={this.handleChange}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label className="label-text" htmlFor="email">Email:</label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value={formData.email}
                            onChange={this.handleChange}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label className="label-text" htmlFor="message">Message:</label>
                        <textarea
                            id="message"
                            name="message"
                            value={formData.message}
                            onChange={this.handleChange}
                            required
                        ></textarea>
                    </div>
                    <div className="form-group" style={{ display: "flex" }}>
                        <label className="label-text" htmlFor="gender">Gender:&nbsp;</label>
                        <div className="gender-options" style={{ display: "flex" }}>
                            <label className="label-text" htmlFor="male">Male</label>
                            <input
                                type="radio"
                                id="male"
                                name="gender"
                                value="male"
                                checked={formData.gender === "male"}
                                onChange={this.handleChange}
                            />
                            <label className="label-text" htmlFor="female">Female</label>
                            <input
                                type="radio"
                                id="female"
                                name="gender"
                                value="female"
                                checked={formData.gender === "female"}
                                onChange={this.handleChange}
                            />
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="label-text">
                            <input
                                type="checkbox"
                                name="agree"
                                checked={formData.agree}
                                onChange={this.handleChange}
                            />
                            I agree to the terms and conditions
                        </label>
                    </div>
                    <div className="form-group" style={{ display: "flex", alignItems: "center" }}>
                        <label className="label-text" htmlFor="department" style={{ marginRight: "10px" }}>Department:</label>
                        <select
                            id="department"
                            name="department"
                            value={formData.department}
                            onChange={this.handleChange}
                            required
                        >
                            <option value="">Select Department</option>
                            <option value="HR">HR</option>
                            <option value="Finance">Finance</option>
                            <option value="IT">IT</option>
                            <option value="Marketing">Marketing</option>
                        </select>
                    </div>
                    <button type="submit" >Submit</button>
                </form>
                {showData && (
                    <div>
                        <h3>Submitted Data:</h3>
                        <p>Name: {formData.name}</p>
                        <p>Email: {formData.email}</p>
                        <p>Message: {formData.message}</p>
                        <p>Gender: {formData.gender}</p>
                        <p>Department: {formData.department}</p>
                    </div>
                )}
            </div>
        );
    }
}

export default MyFormClass;