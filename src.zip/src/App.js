import './App.css';
import MyForm from './Form';
import MyFormClass from './FormClass' 

function App() {
  return (
    <MyFormClass/>
  );
}

export default App;
